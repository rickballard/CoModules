# BPOE Guardrails

- Close here-strings on their own line.
- Apply encoding at write (`Set-Content -Encoding UTF8`).
- Deterministic outputs: same input → same output.
- No silent failures: `$ErrorActionPreference='Stop'`, `Set-StrictMode -Version Latest`.
- Autonomy + auditability: automation visible in repo, leaves logs.

