# Mentor Prompts (generic, replace freely)

- Show me 3 role options matching my strengths and constraints; include comp bands, visa/remote notes.
- Package me for an API-enablement role at a company that hasn't exposed product APIs yet.
- Draft a 4-sprint plan to ship an AI-assisted demo that proves value to a hiring manager in 2 weeks.
- Identify ally communities and conferences where I'd be welcomed and safe to network.
- Turn my last 6 months into bullet-proof resume lines with measurable outcomes.
