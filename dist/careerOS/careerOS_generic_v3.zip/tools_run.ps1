param([string]$RepoName="careerOS",[string]$GitHubUser="")
Write-Host "This is the v3 sample bootstrap; personalize next."
