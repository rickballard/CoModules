param([string]$RepoPath="",[switch]$Confirm)
if(-not $Confirm){ Write-Host "Use -Confirm"; exit 1 }
$starter = Get-Content (Join-Path (Split-Path $MyInvocation.MyCommand.Path) "career_starter.json") -Raw | ConvertFrom-Json
foreach($p in $starter.PSObject.Properties){
  $dest = Join-Path $RepoPath $p.Name
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Set-Content $dest $p.Value -Encoding UTF8
}
