# careerOS — Rainbow Prototype (v2)

🌈 Sample content to demonstrate how careerOS works.
