🌈 SAMPLE Market map options
