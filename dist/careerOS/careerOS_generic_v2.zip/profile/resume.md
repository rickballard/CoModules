🌈 SAMPLE resume
