# lifeOS generic v1 (samples)
