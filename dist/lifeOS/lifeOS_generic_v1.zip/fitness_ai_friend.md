# Fitness AI-Friend — Voice Companion

Mode: caring friend persona, non-judgmental, consent-first.
- Pre-walk checklist (hydration, weather, route safety)
- Session modes: walk, mobility, strength, breathwork
- Voice cues: posture, pacing, encouragement, stop-on-pain
- Reflection: 'what felt good?', 'what to adjust next time?'
- Privacy: local-first where possible; no 3rd-party ads or sales
